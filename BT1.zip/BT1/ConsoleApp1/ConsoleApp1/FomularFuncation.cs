﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
     public class FomularFuncation
     {
        public static int tru(int a, int b)
        {
            return a - b;
        }

        public static int cong(int a, int b)
        {
            return a + b;
        }

        public int nhan(int a, int b)
        {
            return a * b;
        }

        public float chia(float a, float b)
        {
            return a / b;
        }
     }

    public class abc
    {
        public float chia(float a, float b)
        {
            return a / b;
        }
    }
}
