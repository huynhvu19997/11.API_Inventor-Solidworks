﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Inventor;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Attribute = System.Attribute;

namespace FirstAddin
{
    [GuidAttribute("8CB4FC42-8F85-45F1-8654-87502C87BF00")]
    public class FirstAddIn : Inventor.ApplicationAddInServer
    {
        public FirstAddIn()
        {

        }

        private Inventor.Application m_inventorApplication;

        public void Activate(ApplicationAddInSite addInSiteObject, bool firstTime)
        {
            m_inventorApplication = addInSiteObject.Application;

            if (firstTime)
            {
                Ribbon ribbon = m_inventorApplication.UserInterfaceManager.Ribbons["ZeroDoc"];
                RibbonTab tab = ribbon.RibbonTabs["id_TabTools"];
                RibbonPanel panel = tab.RibbonPanels.Add("My Panel", "myPanelID", "{8CB4FC42-8F85-45F1-8654-87502C87BF00}");

                CommandManager cmdManager = m_inventorApplication.CommandManager;
                ControlDefinitions controlDefs = cmdManager.ControlDefinitions;
                ButtonDefinition btnDef = controlDefs.AddButtonDefinition("Vu Pannel", "Mr.Vu Button",
                    CommandTypesEnum.kShapeEditCmdType, null, "Tooltip Text", "Description Text");

                panel.CommandControls.AddButton(btnDef, true);

                btnDef.OnExecute += (NameValueMap Context) => MessageBox.Show("Button clicked!");
            }
        }

        public void Deactivate()
        {
            Marshal.ReleaseComObject(m_inventorApplication);
            m_inventorApplication = null;
        }

        public void ExecuteCommand(int commandID)
        {
            // Method body
        }

        public object Automation => null;
    }
}
