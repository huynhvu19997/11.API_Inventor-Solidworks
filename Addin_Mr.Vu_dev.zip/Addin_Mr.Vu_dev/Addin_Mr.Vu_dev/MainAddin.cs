﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Inventor;
using System.Windows.Forms;
using System.IO.Ports; // kết nối với chip
using System.Runtime.InteropServices;
using Attribute = System.Attribute;
using System.Reflection;
using System.Windows.Media.Imaging;
using System.IO;
using Addin_Mr.Vu_dev.FormHMI;

namespace Addin_Mr.Vu_dev
{
    [GuidAttribute("E63BF544-E029-42E6-8F64-134E89BB097F")]
    public class MainAddin : Inventor.ApplicationAddInServer
    {
        private Inventor.Application m_inventorApplication;
        private ButtonDefinition m_buttonDef;
        private const string iconPath = @"C:\Path\To\Your\Icon\buttonIcon.png";

        public void Activate(ApplicationAddInSite addInSiteObject, bool firstTime)
        {
            m_inventorApplication = addInSiteObject.Application;

            if (firstTime)
            {
                // Load the icon as a stream
                //icon mặc định
                Stream iconStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("InventorAddInWPFButton.Resources.buttonIcon.png");
                BitmapImage icon = new BitmapImage();
                icon.BeginInit();
                icon.StreamSource = iconStream;
                icon.EndInit();

                //custom icon
                //var icon = new BitmapImage(new Uri(iconPath, UriKind.Absolute));

                // Create the button definition with the icon
                var cmdMgr = m_inventorApplication.CommandManager;
                var controlDefs = cmdMgr.ControlDefinitions;
                m_buttonDef = controlDefs.AddButtonDefinition(
                    "Show WPF Form",
                    "ShowWPFButton",
                    CommandTypesEnum.kNonShapeEditCmdType,
                    "E63BF544-E029-42E6-8F64-134E89BB097F",
                    "Show WPF Form",
                    "This button shows a WPF form",
                    icon
                );

                m_buttonDef.OnExecute += ButtonDef_OnExecute;

                // Add the button to all Ribbon panels in all environments
                UserInterfaceManager uiMan = m_inventorApplication.UserInterfaceManager;
                foreach (Ribbon ribbon in uiMan.Ribbons)
                {
                    foreach (RibbonTab tab in ribbon.RibbonTabs)
                    {
                        // Add button to every ribbon panel
                        foreach (RibbonPanel panel in tab.RibbonPanels)
                        {
                            panel.CommandControls.AddButton(m_buttonDef, true);
                        }
                    }
                }
            }
        }

        private void ButtonDef_OnExecute(NameValueMap Context)
        {
            Formtool formtool = new Formtool();
            formtool.ShowDialog();
        }



        public void Deactivate()
        {
            if (m_buttonDef != null)
            {
                Marshal.ReleaseComObject(m_buttonDef);
                m_buttonDef = null;
            }
            if (m_inventorApplication != null)
            {
                Marshal.ReleaseComObject(m_inventorApplication);
                m_inventorApplication = null;
            }
        }

        public void ExecuteCommand(int commandID)
        {

        }

        public object Automation => null;
    }
}
