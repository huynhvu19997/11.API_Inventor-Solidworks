﻿namespace FirstAddin.HMI
{
    partial class ConnectArduino
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Cbb_Port = new System.Windows.Forms.ComboBox();
            this.Cbb_Baurate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.Btn_Open = new System.Windows.Forms.Button();
            this.Btn_Close = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_1ON = new System.Windows.Forms.Button();
            this.btn_1off = new System.Windows.Forms.Button();
            this.btn_2off = new System.Windows.Forms.Button();
            this.btn_2ON = new System.Windows.Forms.Button();
            this.btn_3off = new System.Windows.Forms.Button();
            this.btn_3ON = new System.Windows.Forms.Button();
            this.btn_4off = new System.Windows.Forms.Button();
            this.btn_4ON = new System.Windows.Forms.Button();
            this.Btn_5off = new System.Windows.Forms.Button();
            this.btn_5ON = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.animatedLED5 = new FirstAddin.HMI.AnimatedLED();
            this.animatedLED4 = new FirstAddin.HMI.AnimatedLED();
            this.animatedLED3 = new FirstAddin.HMI.AnimatedLED();
            this.animatedLED2 = new FirstAddin.HMI.AnimatedLED();
            this.animatedLED1 = new FirstAddin.HMI.AnimatedLED();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_Close);
            this.groupBox1.Controls.Add(this.Btn_Open);
            this.groupBox1.Controls.Add(this.Cbb_Baurate);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Cbb_Port);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(234, 155);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "COM PORT SETTING";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "COM PORT: ";
            // 
            // Cbb_Port
            // 
            this.Cbb_Port.FormattingEnabled = true;
            this.Cbb_Port.Location = new System.Drawing.Point(93, 33);
            this.Cbb_Port.Name = "Cbb_Port";
            this.Cbb_Port.Size = new System.Drawing.Size(121, 21);
            this.Cbb_Port.TabIndex = 1;
            this.Cbb_Port.DropDown += new System.EventHandler(this.Cbb_Port_DropDown);
            // 
            // Cbb_Baurate
            // 
            this.Cbb_Baurate.FormattingEnabled = true;
            this.Cbb_Baurate.Items.AddRange(new object[] {
            "9600",
            "38400",
            "57600",
            "115200"});
            this.Cbb_Baurate.Location = new System.Drawing.Point(95, 63);
            this.Cbb_Baurate.Name = "Cbb_Baurate";
            this.Cbb_Baurate.Size = new System.Drawing.Size(121, 21);
            this.Cbb_Baurate.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "BAUD RATE: ";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 173);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(234, 23);
            this.progressBar1.TabIndex = 4;
            // 
            // Btn_Open
            // 
            this.Btn_Open.Location = new System.Drawing.Point(60, 111);
            this.Btn_Open.Name = "Btn_Open";
            this.Btn_Open.Size = new System.Drawing.Size(75, 23);
            this.Btn_Open.TabIndex = 4;
            this.Btn_Open.Text = "OPEN";
            this.Btn_Open.UseVisualStyleBackColor = true;
            this.Btn_Open.Click += new System.EventHandler(this.Btn_Open_Click);
            // 
            // Btn_Close
            // 
            this.Btn_Close.Location = new System.Drawing.Point(141, 111);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Size = new System.Drawing.Size(75, 23);
            this.Btn_Close.TabIndex = 5;
            this.Btn_Close.Text = "Close";
            this.Btn_Close.UseVisualStyleBackColor = true;
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Btn_5off);
            this.groupBox2.Controls.Add(this.btn_5ON);
            this.groupBox2.Controls.Add(this.animatedLED5);
            this.groupBox2.Controls.Add(this.btn_4off);
            this.groupBox2.Controls.Add(this.btn_4ON);
            this.groupBox2.Controls.Add(this.animatedLED4);
            this.groupBox2.Controls.Add(this.btn_3off);
            this.groupBox2.Controls.Add(this.btn_3ON);
            this.groupBox2.Controls.Add(this.animatedLED3);
            this.groupBox2.Controls.Add(this.btn_2off);
            this.groupBox2.Controls.Add(this.btn_2ON);
            this.groupBox2.Controls.Add(this.animatedLED2);
            this.groupBox2.Controls.Add(this.btn_1off);
            this.groupBox2.Controls.Add(this.btn_1ON);
            this.groupBox2.Controls.Add(this.animatedLED1);
            this.groupBox2.Location = new System.Drawing.Point(253, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(535, 154);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "LED CONTROL";
            // 
            // btn_1ON
            // 
            this.btn_1ON.Location = new System.Drawing.Point(11, 70);
            this.btn_1ON.Name = "btn_1ON";
            this.btn_1ON.Size = new System.Drawing.Size(75, 23);
            this.btn_1ON.TabIndex = 1;
            this.btn_1ON.Text = "Bật";
            this.btn_1ON.UseVisualStyleBackColor = true;
            this.btn_1ON.Click += new System.EventHandler(this.btn_1ON_Click);
            // 
            // btn_1off
            // 
            this.btn_1off.Location = new System.Drawing.Point(11, 100);
            this.btn_1off.Name = "btn_1off";
            this.btn_1off.Size = new System.Drawing.Size(75, 23);
            this.btn_1off.TabIndex = 2;
            this.btn_1off.Text = "Tắt";
            this.btn_1off.UseVisualStyleBackColor = true;
            this.btn_1off.Click += new System.EventHandler(this.btn_1off_Click);
            // 
            // btn_2off
            // 
            this.btn_2off.Location = new System.Drawing.Point(100, 99);
            this.btn_2off.Name = "btn_2off";
            this.btn_2off.Size = new System.Drawing.Size(75, 23);
            this.btn_2off.TabIndex = 5;
            this.btn_2off.Text = "Tắt";
            this.btn_2off.UseVisualStyleBackColor = true;
            // 
            // btn_2ON
            // 
            this.btn_2ON.Location = new System.Drawing.Point(100, 69);
            this.btn_2ON.Name = "btn_2ON";
            this.btn_2ON.Size = new System.Drawing.Size(75, 23);
            this.btn_2ON.TabIndex = 4;
            this.btn_2ON.Text = "Bật";
            this.btn_2ON.UseVisualStyleBackColor = true;
            this.btn_2ON.Click += new System.EventHandler(this.btn_2ON_Click);
            // 
            // btn_3off
            // 
            this.btn_3off.Location = new System.Drawing.Point(187, 98);
            this.btn_3off.Name = "btn_3off";
            this.btn_3off.Size = new System.Drawing.Size(75, 23);
            this.btn_3off.TabIndex = 8;
            this.btn_3off.Text = "Tắt";
            this.btn_3off.UseVisualStyleBackColor = true;
            // 
            // btn_3ON
            // 
            this.btn_3ON.Location = new System.Drawing.Point(187, 68);
            this.btn_3ON.Name = "btn_3ON";
            this.btn_3ON.Size = new System.Drawing.Size(75, 23);
            this.btn_3ON.TabIndex = 7;
            this.btn_3ON.Text = "Bật";
            this.btn_3ON.UseVisualStyleBackColor = true;
            // 
            // btn_4off
            // 
            this.btn_4off.Location = new System.Drawing.Point(272, 98);
            this.btn_4off.Name = "btn_4off";
            this.btn_4off.Size = new System.Drawing.Size(75, 23);
            this.btn_4off.TabIndex = 11;
            this.btn_4off.Text = "Tắt";
            this.btn_4off.UseVisualStyleBackColor = true;
            // 
            // btn_4ON
            // 
            this.btn_4ON.Location = new System.Drawing.Point(272, 68);
            this.btn_4ON.Name = "btn_4ON";
            this.btn_4ON.Size = new System.Drawing.Size(75, 23);
            this.btn_4ON.TabIndex = 10;
            this.btn_4ON.Text = "Bật";
            this.btn_4ON.UseVisualStyleBackColor = true;
            // 
            // Btn_5off
            // 
            this.Btn_5off.Location = new System.Drawing.Point(358, 98);
            this.Btn_5off.Name = "Btn_5off";
            this.Btn_5off.Size = new System.Drawing.Size(75, 23);
            this.Btn_5off.TabIndex = 14;
            this.Btn_5off.Text = "Tắt";
            this.Btn_5off.UseVisualStyleBackColor = true;
            // 
            // btn_5ON
            // 
            this.btn_5ON.Location = new System.Drawing.Point(358, 68);
            this.btn_5ON.Name = "btn_5ON";
            this.btn_5ON.Size = new System.Drawing.Size(75, 23);
            this.btn_5ON.TabIndex = 13;
            this.btn_5ON.Text = "Bật";
            this.btn_5ON.UseVisualStyleBackColor = true;
            // 
            // animatedLED5
            // 
            this.animatedLED5.BackColor = System.Drawing.Color.DarkRed;
            this.animatedLED5.Location = new System.Drawing.Point(373, 19);
            this.animatedLED5.Name = "animatedLED5";
            this.animatedLED5.Size = new System.Drawing.Size(45, 43);
            this.animatedLED5.TabIndex = 12;
            this.animatedLED5.Text = "animatedLED5";
            this.animatedLED5.UseVisualStyleBackColor = false;
            // 
            // animatedLED4
            // 
            this.animatedLED4.BackColor = System.Drawing.Color.DarkRed;
            this.animatedLED4.Location = new System.Drawing.Point(287, 19);
            this.animatedLED4.Name = "animatedLED4";
            this.animatedLED4.Size = new System.Drawing.Size(45, 43);
            this.animatedLED4.TabIndex = 9;
            this.animatedLED4.Text = "animatedLED4";
            this.animatedLED4.UseVisualStyleBackColor = false;
            // 
            // animatedLED3
            // 
            this.animatedLED3.BackColor = System.Drawing.Color.DarkRed;
            this.animatedLED3.Location = new System.Drawing.Point(202, 19);
            this.animatedLED3.Name = "animatedLED3";
            this.animatedLED3.Size = new System.Drawing.Size(45, 43);
            this.animatedLED3.TabIndex = 6;
            this.animatedLED3.Text = "animatedLED3";
            this.animatedLED3.UseVisualStyleBackColor = false;
            // 
            // animatedLED2
            // 
            this.animatedLED2.BackColor = System.Drawing.Color.DarkRed;
            this.animatedLED2.Location = new System.Drawing.Point(115, 20);
            this.animatedLED2.Name = "animatedLED2";
            this.animatedLED2.Size = new System.Drawing.Size(45, 43);
            this.animatedLED2.TabIndex = 3;
            this.animatedLED2.Text = "animatedLED2";
            this.animatedLED2.UseVisualStyleBackColor = false;
            // 
            // animatedLED1
            // 
            this.animatedLED1.BackColor = System.Drawing.Color.DarkRed;
            this.animatedLED1.Location = new System.Drawing.Point(26, 21);
            this.animatedLED1.Name = "animatedLED1";
            this.animatedLED1.Size = new System.Drawing.Size(45, 43);
            this.animatedLED1.TabIndex = 0;
            this.animatedLED1.Text = "animatedLED1";
            this.animatedLED1.UseVisualStyleBackColor = false;
            // 
            // ConnectArduino
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.groupBox1);
            this.Name = "ConnectArduino";
            this.Text = "ConnectArduino";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ConnectArduino_FormClosing);
            this.Load += new System.EventHandler(this.ConnectArduino_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_Close;
        private System.Windows.Forms.Button Btn_Open;
        private System.Windows.Forms.ComboBox Cbb_Baurate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Cbb_Port;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Btn_5off;
        private System.Windows.Forms.Button btn_5ON;
        private AnimatedLED animatedLED5;
        private System.Windows.Forms.Button btn_4off;
        private System.Windows.Forms.Button btn_4ON;
        private AnimatedLED animatedLED4;
        private System.Windows.Forms.Button btn_3off;
        private System.Windows.Forms.Button btn_3ON;
        private AnimatedLED animatedLED3;
        private System.Windows.Forms.Button btn_2off;
        private System.Windows.Forms.Button btn_2ON;
        private AnimatedLED animatedLED2;
        private System.Windows.Forms.Button btn_1off;
        private System.Windows.Forms.Button btn_1ON;
        private AnimatedLED animatedLED1;
        private System.IO.Ports.SerialPort serialPort1;
    }
}