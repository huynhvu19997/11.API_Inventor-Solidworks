﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace FirstAddin.HMI
{
    public partial class ConnectArduino : Form
    {
        public ConnectArduino()
        {
            InitializeComponent();
        }

        private void ButtonControl_Initialization(bool state)
        {
            btn_1off.Enabled = state;
            btn_1ON.Enabled = state;
            btn_2off.Enabled = state;
            btn_2ON.Enabled = state;
            btn_3off.Enabled = state;
            btn_3ON.Enabled = state;
            btn_4off.Enabled = state;
            btn_4ON.Enabled = state;
            Btn_5off.Enabled = state;
            btn_5ON.Enabled = state;
        }

        private void AnimatedLed_Initialiaztion()
        {
            animatedLED1.BackColor = Color.DarkRed;
            animatedLED2.BackColor = Color.DarkRed;
            animatedLED3.BackColor = Color.DarkRed;
            animatedLED4.BackColor = Color.DarkRed;
            animatedLED5.BackColor = Color.DarkRed;
        }

        private void Button_SendData(string data, Button numberLed, Color LEDcolor)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Write(data);
                    animatedLED1.BackColor = LEDcolor;
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
        }

        private void ConnectArduino_Load(object sender, EventArgs e)
        {
            Btn_Open.Enabled = true;
            Btn_Close.Enabled = false;
            progressBar1.Value = 0;
            Cbb_Baurate.Text = "115200";
            ButtonControl_Initialization(false);
            AnimatedLed_Initialiaztion();
        }

        private void Cbb_Port_DropDown(object sender, EventArgs e)
        {
            string[] portLists = SerialPort.GetPortNames();
            Cbb_Port.Items.Clear();
            Cbb_Port.Items.AddRange(portLists);
        }

        private void Btn_Open_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = Cbb_Port.Text;
                serialPort1.BaudRate = Convert.ToInt32(Cbb_Baurate.Text);
                serialPort1.Open();
                serialPort1.Write("#"); // this is a clear data in arduino when first time connected to arduino

                Btn_Open.Enabled = false;
                Btn_Close.Enabled = true;
                progressBar1.Value = 100;
                ButtonControl_Initialization(true);

            }
            catch ( Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();

                    Btn_Open.Enabled = true;
                    Btn_Close.Enabled = false;
                    progressBar1.Value = 0;
                    ButtonControl_Initialization(false);
                }
                catch(Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
        }

        private void ConnectArduino_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                }
                catch(Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
        }

        private void btn_1ON_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Write("1ON#");
                    animatedLED1.BackColor = Color.Red;
                }
                catch(Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
        }

        private void btn_1off_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Write("1OFF#");
                    animatedLED1.BackColor = Color.DarkRed;
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
        }

        private void btn_2ON_Click(object sender, EventArgs e)
        {
            Button_SendData("2ON#", animatedLED2, Color.Red);
        }
    }
}
