﻿using System.Runtime.InteropServices;
using System.Windows.Forms;
using FirstAddin;
using Inventor;
using System.Drawing; // Thêm tham chiếu đến System.Drawing
using System.IO; // Để đọc tập tin hình ảnh
using System.Windows.Media.Imaging;
using System;
using stdole;
using FirstAddin.HMI;

[GuidAttribute("8CB4FC42-8F85-45F1-8654-87502C87BF00")]
public class FirstAddIn : Inventor.ApplicationAddInServer
{
    public FirstAddIn()
    {

    }

    private Inventor.Application m_inventorApplication;
    private ButtonDefinition m_buttonDef;
    private ButtonDefinition m_buttonDef2;
    private const string iconPath = @"D:\1. OE_Keson\5.2024\3.R&D\WPF\FirstAddin\FirstAddin\1.jpg";

    public void Activate(ApplicationAddInSite addInSiteObject, bool firstTime)
    {
        m_inventorApplication = addInSiteObject.Application;

        if (firstTime)
        {


            // Tạo một ribbon mới
            UserInterfaceManager uiMan = m_inventorApplication.UserInterfaceManager;
            Ribbon ribbon = uiMan.Ribbons["ZeroDoc"];

            // Thêm một tab vào ribbon
            RibbonTab tab = ribbon.RibbonTabs.Add("Mr.vu tool", "CustomTabID", "{8CB4FC42-8F85-45F1-8654-87502C87BF00}");

            // Thêm một panel vào tab
            RibbonPanel panel = tab.RibbonPanels.Add("Mr Vu", "myPanelID", "{8CB4FC42-8F85-45F1-8654-87502C87BF00}");

            //Ribbon ribbon = m_inventorApplication.UserInterfaceManager.Ribbons["Assembly"];
            //RibbonTab tab = ribbon.RibbonTabs["id_TabAssemble"];
            //RibbonPanel panel = tab.RibbonPanels.Add("My Panel", "myPanelID", "{8CB4FC42-8F85-45F1-8654-87502C87BF00}");

            Inventor.IPictureDisp iconDisp = PictureDispConverter.ToIPictureDisp(Image.FromFile(iconPath));

            CommandManager cmdManager = m_inventorApplication.CommandManager;
            ControlDefinitions controlDefs = cmdManager.ControlDefinitions;
            ButtonDefinition btnDef = controlDefs.AddButtonDefinition("Vu Pannel", "Mr.Vu Button",
                CommandTypesEnum.kShapeEditCmdType, null, "Tooltip Text", "Description Text", iconDisp, iconDisp); // đầu tiên là small icon, thứ 2 là large icon
      

            m_buttonDef2 = controlDefs.AddButtonDefinition(
                "Button 2",
                "Button2_InternarlName",
                CommandTypesEnum.kShapeEditCmdType,
                null,
                "Tooltip Text 2",
                "Description Text 2"
            );

            panel.CommandControls.AddButton(btnDef, true);
            panel.CommandControls.AddButton(m_buttonDef2, true);

            m_buttonDef = btnDef; // Gán giá trị cho m_buttonDef
            m_buttonDef.OnExecute += ButtonDef_OnExecute;

            m_buttonDef2.OnExecute += ButtonDef1_OnExecute;
        }
    }

    private void ButtonDef_OnExecute(NameValueMap Context)
    {
        form1 formtool = new form1();
        formtool.ShowDialog();
        //MessageBox.Show("ABc");
    }

    private void ButtonDef1_OnExecute(NameValueMap Context)
    {
        ConnectArduino formMicrocontroler = new ConnectArduino();
        formMicrocontroler.ShowDialog();
    }

    public void Deactivate()
    {
        Marshal.ReleaseComObject(m_inventorApplication);
        m_inventorApplication = null;
    }

    public void ExecuteCommand(int commandID)
    {
        // Method body
    }

    public object Automation => null;

    public sealed class PictureDispConverter : System.Windows.Forms.AxHost
    {
        private PictureDispConverter() : base(null) { }

        public static Inventor.IPictureDisp ToIPictureDisp(Image image)
        {
            return (Inventor.IPictureDisp)AxHost.GetIPictureDispFromPicture(image);
        }
    }

}
